import data_io
def main():
	data = data_io.read_